class Termin {
  final String id;
  final String name;
  final DateTime date;
  // final String vreme;

  Termin({
    required this.id,
    required this.name,
    required this.date,
    // required this.vreme
  });
}
