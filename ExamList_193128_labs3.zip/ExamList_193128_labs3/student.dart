class Student {
  String ime;
  String prezime;
  String brIndeks;

  Student({this.ime, this.prezime, this.brIndeks});
}
