package com.example.lab_mis

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
